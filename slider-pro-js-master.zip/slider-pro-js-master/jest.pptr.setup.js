global.BASE_URL = 'http://localhost:3000/test/assets/pages/';
global.E2E_BASE_URL = 'http://localhost:3000/examples/';