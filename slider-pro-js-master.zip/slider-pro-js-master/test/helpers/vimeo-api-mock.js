import VimeoAPIPlayerMock from './vimeo-api-player-mock.js';

window.Vimeo = window.Vimeo || {};
window.Vimeo.Player = VimeoAPIPlayerMock;
